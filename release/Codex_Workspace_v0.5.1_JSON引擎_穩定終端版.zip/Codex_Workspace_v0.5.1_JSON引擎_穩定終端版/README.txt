Codex Workspace v0.5.1｜JSON 引擎＋穩定終端版

使用方式：解壓後雙擊「安裝並啟動_v0.5.1.bat」。
主聊天使用 codex exec --json；右上角 >_ 為獨立穩定 PowerShell 終端。
